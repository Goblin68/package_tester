#' Fit a Cox proportional Hazards Regression Model
#' 
#' Utilizes tidyverse syntax to visualize Cox proportional hazards predictions.
#' @param time A vector of time values, like what would be input into Surv()
#' @param time2 A vector of any secondary value that Surv() accepts (time2, status, or type)
#' @param treatments A single treatment or a vector of treatments
#' @param data Data that columns come from, if separate from or not provided in the ggplot call
#' @param facet_x A single factor or a vector of factors to facet by in the x direction
#' @param facet_y A single factor or a vector of factors to facet by in the y direction
#' @details 
#' This function uses the coxph function in the survival package to visualize Cox Proportional Hazards (CPH) survival curves within the Tidyverse ecosystem.
#' The Cox proportional hazards regression model is a versatile semiparametric method used to model survival data.  It applies to cases in which hazards can be modeled as follows:
#' 
#' \deqn{ h(t) = h_0(t) \exp \left\{ b_1 x_1 + b_2 x_2 + \ldots \right\}}
#' 
#' upon estimation of the model coefficients, the above formula can be reexpressed in terms of the survival probability.  This expression is given by 
#' 
#' \deqn{ S(t) = S_0(t)^{\exp{\beta}} }
#' \deqn{ log[S(t)] = exp\{\beta\} log[S_0(t)] }
#' 
#' Full details of this model are found in the foundational "Regression Models and Life-Tables" paper by D.R. Cox (1972).
#' Note: Though this function accepts strata in its arguments, the CPH predictions are identical to that of the model in which the stratifying variable is a treatment instead.  The only difference specifying a strata makes is in the display of line type.
#' @export
#' @import survival ggplot2
#' @seealso
#' The alternate version that accepts coxph formulas: [geom_coxph()], [geom_coxph2()]
#' The function that does the underlying work for both km and km2: [ggplot_add.survreg_plot()]
#' @examples
#' load(mfg)
#' mfg %>%
#' geom_coxph(ttf,status,mfgLocation) +
#' labs(...) +
#' theme_minimal()



geom_coxph = function(time = NULL, time2 = NULL, treatments = NULL, strata = NULL, ..., facet_x = NULL, facet_y = NULL, failure = F, data = NULL){
  #Check if they piped in
  time = enquo(time)
  if (!rlang:::quo_is_null(time)){
    if (rlang:::quo_get_expr(time) == "."){
      if (tryCatch(length(unlist(rlang:::eval_tidy(time))) > 1, error = function(e){FALSE})){
        stop("piped in to geom_survreg instead of using +")
      }
    }
  }
  structure(
    "",
    class = "survivalverse_plot",
    fn = create_coxph_plot,
    time = time,
    time2 = enquo(time2),
    treatments = enquo(treatments),
    strata = enquo(strata),
    extras = enquos(...),
    facet_x = enquo(facet_x),
    facet_y = enquo(facet_y),
    inherit = T,
    failure = failure,
    data = data
  )
}


create_coxph_plot = function(args, plot){
  #Error handling dummy functions so that users see "Error in geom_km"
  #when an error is raised rather than "Error in ggplot_add.km_plot"
  raise_error = function(..., error = T){
    txt = paste(..., sep = "")
    geom_coxph(txt, error)
  }
  geom_coxph = function(time, time2, treatments = NULL, strata = NULL, ...){
    if (time2){
      stop(time)
    } else{
      warning(time)
    }
  }
  #Checks for inheritance
  if (is.null(plot$survivalverse_inherit)){
    plot$survivalverse_inherit = args[c("time", "time2", "treatments", "strata", "failure")]
  } else{
    args[c("time", "time2", "treatments", "strata", "failure")] = plot$survivalverse_inherit
  }
  args = km.survreg.coxph_wrangle_args(args, plot)
  args$coxph = coxph(args$formula, data = args$data)
  coxph_create_plot(args, plot)
}

coxph_create_plot = function(args, plot){
  ds = rlang:::eval_tidy(args$coxph$call[[3]], env = attributes(args$coxph$terms)$.Environment)
  form = rlang:::eval_tidy(
    args$coxph$call[[2]], env = attributes(args$coxph$terms)$.Environment)
  
      print("Model form")
      print(form)
  
  time_col = paste(form[[2]][[2]])
      print("time_col")
      a <<- time_col
  names = unlist(strsplit(as.character(form[[3]])[-1], " \\+ "))
  trtnames = names[!grepl("^strata\\(.*\\)$", names) &
                     !(names %in% c(args$facet_x, args$facet_y, "1"))]
  
  stratanames = sapply(names[grepl("^strata\\(.*\\)$", names) &
                               !(names %in% c(paste("strata(", append(args$facet_x, args$facet_y), ")", sep = ""), "1"))],
                       function(x){substr(x, 8, nchar(x)-1)})
  df = expand.grid(lapply(c(trtnames, stratanames, args$facet_x, args$facet_y), function(x){unique(ds[[x]])}))
  names(df) = c(trtnames, stratanames, args$facet_x, args$facet_y)
  if (length(trtnames) != 0 & length(stratanames) != 0){
    df$groups = interaction(df[c(trtnames, stratanames)])
    df$Treatments = interaction(df[trtnames])
    df$Strata = interaction(df[stratanames])
  } else if (length(trtnames) != 0){
    df$groups = interaction(df[trtnames])
    df$Treatments = interaction(df[trtnames])
    Strata = NULL
        print("df$groups & df$Treatments")
        print(df$groups)
        print(df$Treatments)
  } else if (length(stratanames) != 0){
    df$groups = interaction(df[stratanames])
    df$Strata = interaction(df[stratanames])
    Treatments = NULL
  } else{
    groups = as.factor(numeric(nrow(df)))
    Treatments = NULL
    Strata = NULL
  }
  plot$treatments = numeric(length(unique(df$Treatments)))
  names(plot$treatments) = unique(df$Treatments)
  plot$strata = numeric(length(unique(df$Strata)))
  names(plot$strata) = unique(df$Strata)
  
  if (length(args$facet_x) == 0){
    args$facet_x = "."
  }
  if (length(args$facet_y) == 0){
    args$facet_y = "."
  }
  args$facet = facet_grid(as.formula(paste(
    paste(args$facet_y, collapse = " + "), "~", paste(args$facet_x, collapse = " + "))))
  #labels :3
  if (args$failure){
    lab = labs(caption = paste("AIC:", round(AIC(args$coxph), 2)), x = "Time", y = "Failure Probability")
  } else{
    lab = labs(caption = paste("AIC:", round(AIC(args$coxph), 2)), x = "Time", y = "Survival Probability")
  }
  
  times = seq(min(ds[[time_col]]), max(ds[[time_col]]), (max(ds[[time_col]])-min(ds[[time_col]]))/1000)
      print("length of times vec")
      print(length(times))
  df = df %>% expand_grid(time = times, celltype=celltype,status = 1) %>%
    as.data.frame()
  print("dim(df) after expand_grid")
  print(dim(df))
  
      # ds2 = df %>% 
      #   # expand_grid(time=times) %>% 
      #   rename(time=times),
      #   mutate(status=1) %>% 
      #   select(time,status,celltype) %>%
      #   as.data.frame()
      
      b <<- df
          print("ds after expand_grid")
          # print(df)
          print(dim(df))
          # print("args$coxph")
          # print(args$coxph)
  df$preds = predict(args$coxph, df, type = "survival")
  plot + geom_line(aes(time, preds, color = Treatments, linetype = Strata, group = groups), data = df, na.rm = T) +
    args$facet + lab
}


